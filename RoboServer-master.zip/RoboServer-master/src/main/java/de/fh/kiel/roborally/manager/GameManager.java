package de.fh.kiel.roborally.manager;

import org.springframework.stereotype.Service;

/**
 * Manages the state of all games and all actions that take place during each game.
 *
 * @author jpr
 */
@Service
public class GameManager {
}
