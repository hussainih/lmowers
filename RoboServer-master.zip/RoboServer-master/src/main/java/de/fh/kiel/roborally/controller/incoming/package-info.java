/**
 * This package contains all controllers, that process incoming requests from all clients
 *
 * @author jpr
 */
package de.fh.kiel.roborally.controller.incoming;