package de.fh.kiel.roborally.controller.incoming;

import de.fh.kiel.roborally.model.*;
import javafx.application.Platform;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.*;

import static de.fh.kiel.roborally.model.BoardElement.*;
import static de.fh.kiel.roborally.model.Card.*;
import static de.fh.kiel.roborally.model.Direction.*;

@Service
public class GamesService {
    List<GameState> gameStates = new ArrayList<>();
    Board board = new Board();
    BoardElement[][] boardElements = new BoardElement[][]{
            {PIT, FAST_CB_SOUTH, FAST_CB_SOUTH, CHECK1, EMPTY, EMPTY, EMPTY, EMPTY, EMPTY, EMPTY},
            {EMPTY, FAST_CB_CROSS_CCW_12_TO_3, FAST_CB_CROSS_CW_3_TO_6, FAST_CB_WEST, FAST_CB_WEST, FAST_CB_WEST, FAST_CB_WEST, FAST_CB_WEST, FAST_CB_CROSS_CCW_3_TO_6, FAST_CB_WEST},
            {EMPTY, FAST_CB_SOUTH, EMPTY, EMPTY, EMPTY, EMPTY, EMPTY, EMPTY, FAST_CB_CROSS_CCW_6_TO_9, FAST_CB_WEST},
            {EMPTY, FAST_CB_SOUTH, EMPTY, WALL_NORTH_SL_END, EMPTY, WALL_WEST_SL_START, WALL_EAST_SL_END, EMPTY, FAST_CB_NORTH, EMPTY},
            {EMPTY, FAST_CB_SOUTH, EMPTY, WALL_SOUTH_SL_START, EMPTY, EMPTY, EMPTY, EMPTY, FAST_CB_NORTH, EMPTY},
            {EMPTY, FAST_CB_SOUTH, EMPTY, REBOOT_EAST, EMPTY, EMPTY, WALL_NORTH_SL_START, EMPTY, FAST_CB_NORTH, EMPTY},
            {EMPTY, FAST_CB_SOUTH, EMPTY, WALL_WEST_SL_END, WALL_EAST_SL_START, EMPTY, WALL_SOUTH_SL_END, EMPTY, FAST_CB_NORTH, EMPTY},
            {FAST_CB_EAST, FAST_CB_CROSS_CW_12_TO_3, PIT, EMPTY, EMPTY, EMPTY, EMPTY, EMPTY, FAST_CB_NORTH, EMPTY},
            {FAST_CB_EAST, FAST_CB_CROSS_CCW_9_TO_12, FAST_CB_EAST, FAST_CB_EAST, FAST_CB_EAST, FAST_CB_EAST, FAST_CB_EAST, FAST_CB_CROSS_CW_9_TO_12, FAST_CB_CROSS_CW_6_TO_9, EMPTY},
            {EMPTY, EMPTY, EMPTY, EMPTY, EMPTY, EMPTY, EMPTY, FAST_CB_NORTH, FAST_CB_NORTH, EMPTY},
            {SLOW_CB_NORTH, EMPTY, EMPTY, EMPTY, WALL_NORTH, WALL_NORTH, EMPTY, EMPTY, EMPTY, SLOW_CB_NORTH},
            {EMPTY, START, WALL_WEST, EMPTY, START, START, EMPTY, WALL_EAST, START, EMPTY},
            {EMPTY, EMPTY, EMPTY, START, ANT_NORTH, EMPTY, START, EMPTY, EMPTY, EMPTY}
    };

    /**
     * Returns all games present on the Server
     *
     * @return List of GameStates
     */
    List<GameState> getAllGames() {
        return this.gameStates;
    }


    /**
     * Returns all players in a game
     *
     * @param id ID of the game whose players are required
     * @return List of players in a GameState
     */
    List<Player> getAllPlayers(String id) {
        GameState gameState = getGameById(id);
        List<Player> players = new ArrayList<Player>(gameState.getPlayers());
        return players;
    }

    /**
     * Creates a new GameState object and adds into the GameState list
     *
     * @param gameView The view received by the Controller
     * @return is the GameState added?
     */
    boolean createGame(GameView gameView) {
        board.setElements(boardElements);
        GameState gameState = new GameState(gameView.getId(), gameView.getMaxRobotCount(), gameView.getName(), board);
        return this.gameStates.add(gameState);
    }

    /**
     * Adds a player in the player set of the game denoting that the player has joined the game
     *
     * @param id         - ID of the game to be joined
     * @param playerView - Data of the player to be saved
     * @return The GameState that was changed
     */
    boolean joinGame(String id, PlayerView playerView) {
        GameState gameState = getGameById(id);
        int index = this.gameStates.indexOf(gameState);
        Player player = new Player(playerView.getId(), playerView.getName(), playerView.getSecret(), playerView.getClientUri(), playerView.getRobotName());
        System.out.println(playerView.getSecret());
        boolean add = gameState.addPlayer(player);
        this.gameStates.set(index, gameState);
        return add;
    }

    /**
     * Returns a GameState with the given ID
     *
     * @param id ID of the game to find
     * @return A GameState object found in List of GameStates
     */
    GameState getGameById(String id) {
        GameState gameStateFound = null;
        for (GameState gameState : gameStates) {
            if (gameState.getId().equals(id)) {
                gameStateFound = gameState;
            }
        }
        return gameStateFound;
    }


    /**
     * Returns a player object
     *
     * @param gameId   - The id of the game the player belongs to
     * @param playerId - The id of the player
     * @return - a Player object
     */
    Player getPlayerById(String gameId, String playerId) {
        Player playerFound = null;
        GameState gameState = getGameById(gameId);

        for (Player player : gameState.getPlayers()) {
            if (player.getId().equals(playerId)) {
                playerFound = player;
            }
        }
        return playerFound;
    }

    /**
     * Updates the robot of the player
     *
     * @param gameId     - The id of the game the player belongs to
     * @param playerId   - The id of the player
     * @param playerView - The updated player
     * @return - was the player updated?
     */
    boolean updatePlayerRobot(String gameId, String playerId, PlayerView playerView) {
        GameState gameState = getGameById(gameId);
        int index = this.gameStates.indexOf(gameState);
        Player player = getPlayerById(gameId, playerId);
        gameState.getPlayers().remove(player);
        Player updatedPlayer = new Player(playerView.getId(), playerView.getName(), playerView.getSecret(), playerView.getClientUri(), playerView.getRobotName());

        if (player.getPositionX() != null) {
            updatedPlayer.setPositionX(player.getPositionX());
            updatedPlayer.setPositionY(player.getPositionY());
        }

        updatedPlayer.setDirection(NORTH);
        System.out.println(String.format("Direction of %s is %s", updatedPlayer.getName(), updatedPlayer.getDirection().toString()));
        boolean update = gameState.addPlayer(updatedPlayer);
        this.gameStates.set(index, gameState);
        return update;
    }

    /**
     * Updates the position of the player
     *
     * @param gameId     - The id of the game the player belongs to
     * @param playerId   - The id of the player
     * @param playerView - The updated player
     * @param posX       - The X position of the player
     * @param posY       - The Y position of the player
     * @return - was the player updated?
     */
    boolean updatePlayerPosition(String gameId, String playerId, PlayerView playerView, int posX, int posY) {
        GameState gameState = getGameById(gameId);
        int index = this.gameStates.indexOf(gameState);
        Player player = getPlayerById(gameId, playerId);
        gameState.getPlayers().remove(player);
        Player updatedPlayer = new Player(playerView.getId(), playerView.getName(), playerView.getSecret(), playerView.getClientUri(), playerView.getRobotName());
        updatedPlayer.setPositionX(posX);
        updatedPlayer.setPositionY(posY);
        updatedPlayer.setDirection(NORTH);
        boolean update = gameState.addPlayer(updatedPlayer);
        this.gameStates.set(index, gameState);
        return update;
    }

    /**
     * Updates the players with random robots and start position if they haven't chosen yet
     *
     * @param gameId      - The id of the game
     * @param playerViews - The players part of that game
     * @return - Were the players updated?
     */
    boolean updatePlayerRandom(String gameId, List<PlayerView> playerViews) {
        GameState gameState = getGameById(gameId);
        int index = this.gameStates.indexOf(gameState);
        boolean update = false;

        Map<String, Boolean> robots = new HashMap<>();
        robots.put("Nibbler", false);
        robots.put("Roomba", false);
        robots.put("Spin", false);
        robots.put("Smash", false);
        robots.put("Twitch", false);
        robots.put("Twonky", false);

        //Checking for start cell
        // [1, 1] || [3, 2] || [4, 1] || [5, 1] || [6, 2] || [8, 1]
        Map<String, Boolean> positions = new HashMap<>();
        positions.put("1,1", false);
        positions.put("3,2", false);
        positions.put("4,1", false);
        positions.put("5,1", false);
        positions.put("6,2", false);
        positions.put("8,1", false);

        for (PlayerView playerView : playerViews) {
            if (playerView.getRobotName().equals("Nibbler"))
                robots.put("Nibbler", true);
            else if (playerView.getRobotName().equals("Roomba"))
                robots.put("Roomba", true);
            else if (playerView.getRobotName().equals("Spin"))
                robots.put("Spin", true);
            else if (playerView.getRobotName().equals("Smash"))
                robots.put("Smash", true);
            else if (playerView.getRobotName().equals("Twitch"))
                robots.put("Twitch", true);
            else if (playerView.getRobotName().equals("Twonky"))
                robots.put("Twonky", true);

            Player player = getPlayerById(gameId, playerView.getId());
            if ((player.getPositionX() != null) && player.getPositionY() == 1 && player.getPositionX() == 1)
                positions.put("1,1", true);
            if ((player.getPositionX() != null) && player.getPositionY() == 3 && player.getPositionX() == 2)
                positions.put("3,2", true);
            if ((player.getPositionX() != null) && player.getPositionY() == 4 && player.getPositionX() == 1)
                positions.put("4,1", true);
            if ((player.getPositionX() != null) && player.getPositionY() == 5 && player.getPositionX() == 1)
                positions.put("5,1", true);
            if ((player.getPositionX() != null) && player.getPositionY() == 6 && player.getPositionX() == 2)
                positions.put("6,2", true);
            if ((player.getPositionX() != null) && player.getPositionY() == 8 && player.getPositionX() == 1)
                positions.put("8,1", true);
        }


        for (PlayerView playerView : playerViews) {
            Player player = getPlayerById(gameId, playerView.getId());
            String selectedRobot = "";
            Integer posX = -1;
            Integer posY = -1;
            boolean modifiedRobot = false;
            boolean modifiedPosition = false;
            //Player updatedPlayer = new Player(playerView.getId(), playerView.getName(), playerView.getSecret(), playerView.getClientUri(), playerView.getRobotName());
            if (player.getRobotName().isEmpty()) {
                for (Map.Entry<String, Boolean> entry : robots.entrySet()) {
                    String key = entry.getKey();
                    Boolean value = entry.getValue();
                    if (!value) {
                        selectedRobot = key;
                        robots.put(key, true);
                        modifiedRobot = true;
                        break;
                    }
                }

            }
            if (player.getPositionX() == null && player.getPositionY() == null) {
                for (Map.Entry<String, Boolean> entry : positions.entrySet()) {
                    String key = entry.getKey();
                    Boolean value = entry.getValue();
                    if (!value) {
                        posY = Character.getNumericValue(key.charAt(0));
                        posX = Character.getNumericValue(key.charAt(2));
                        positions.put(key, true);
                        modifiedPosition = true;
                        break;
                    }
                }
            }

            if (modifiedRobot && !modifiedPosition) {
                gameState.getPlayers().remove(player);
                Player updatedPlayer = new Player(playerView.getId(), playerView.getName(), playerView.getSecret(), playerView.getClientUri(), selectedRobot);

                if (player.getPositionX() != null) {
                    updatedPlayer.setPositionX(player.getPositionX());
                    updatedPlayer.setPositionY(player.getPositionY());
                }

                updatedPlayer.setDirection(NORTH);
                update = gameState.addPlayer(updatedPlayer);
                this.gameStates.set(index, gameState);
                System.out.println("---------------ROBOT WAS MODIFIED-----------");
            } else if (modifiedPosition && !modifiedRobot) {
                gameState.getPlayers().remove(player);
                Player updatedPlayer = new Player(playerView.getId(), playerView.getName(), playerView.getSecret(), playerView.getClientUri(), playerView.getRobotName());
                updatedPlayer.setPositionX(posX + 10);
                updatedPlayer.setPositionY(posY);
                updatedPlayer.setDirection(NORTH);
                update = gameState.addPlayer(updatedPlayer);
                this.gameStates.set(index, gameState);
                System.out.println("---------------POSITION WAS MODIFIED-----------");
            } else if (modifiedRobot && modifiedPosition) {
                gameState.getPlayers().remove(player);
                Player updatedPlayer = new Player(playerView.getId(), playerView.getName(), playerView.getSecret(), playerView.getClientUri(), selectedRobot);
                updatedPlayer.setPositionX(posX + 10);
                updatedPlayer.setPositionY(posY);
                updatedPlayer.setDirection(NORTH);
                update = gameState.addPlayer(updatedPlayer);
                this.gameStates.set(index, gameState);
                System.out.println("---------------ROBOT & POSITION WAS MODIFIED-----------");
            }

        }
        return update;
    }

    /**
     * An outgoing function that tells the clients about a new player joining the game
     *
     * @param gameId  The ID of the game
     * @param players List of players to post
     */
    void updatePreGame(String gameId, List<PlayerView> players) {
        System.out.println(gameId);
        try {
            for (PlayerView playerView : players) {
                RestTemplate restTemplate = new RestTemplate();
                String format = String.format("%s" + "games/%s/updateList", playerView.getClientUri(), gameId);
                restTemplate.postForObject(format, players, ResponseEntity.class);
                System.out.println("I HAVE UPDATED PRE GAME TABLE FOR " + format);
            }
        } catch (HttpServerErrorException e) {
            throw e;
        }
    }

    /**
     * An outgoing function that starts the game for all clients of a particular game
     *
     * @param gameId  - The id of the game to start
     * @param players - The list of players belonging to the game
     */
    public void startGames(String gameId, List<PlayerView> players) {
        for (PlayerView playerView : players) {
            RestTemplate restTemplate = new RestTemplate();
            String format = String.format("%s" + "games/%s/start", playerView.getClientUri(), gameId);
            restTemplate.postForObject(format, players, ResponseEntity.class);
            System.out.println("I HAVE CHANGED SCREEN FOR " + format);
        }
    }


    /**
     * Informs all clients of a chosen Robot
     *
     * @param gameId  - The id of the game to start
     * @param players - The list of players belonging to the game
     */
    public void chooseRobot(String gameId, List<PlayerView> players) {
        for (PlayerView playerView : players) {
            RestTemplate restTemplate = new RestTemplate();
            String format = String.format("%s" + "games/%s/robot", playerView.getClientUri(), gameId);
            restTemplate.postForObject(format, players, ResponseEntity.class);
            System.out.println("I HAVE INFORMED THE ROBOT FOR " + format);
        }
    }

    /**
     * Informs all clients of a chosen position
     *
     * @param gameId  - The id of the game to start
     * @param players - The list of players belonging to the game
     * @param posX    - The position chosen X
     * @param posY    - The position chosen Y
     */
    public void choosePosition(String gameId, List<PlayerView> players, String posX, String posY, String playerName) {
        for (PlayerView playerView : players) {
            RestTemplate restTemplate = new RestTemplate();
            String format = String.format("%s" + "games/%s/position?posX=%s&posY=%s&who=%s", playerView.getClientUri(), gameId, posX, posY, playerName);
            restTemplate.postForObject(format, players, ResponseEntity.class);
            System.out.println("I HAVE INFORMED THE POSITION FOR " + format);
        }
    }

    /**
     * Moves all clients to the game screen after randomizing their robots and start positions (If they hadn't selected it)
     *
     * @param gameId  - The id of the game to start
     * @param players - The list of players belonging to the game
     */
    public void randomiseSelection(String gameId, List<PlayerView> players) {
        for (PlayerView playerView : players) {
            RestTemplate restTemplate = new RestTemplate();
            String format = String.format("%s" + "games/%s/random", playerView.getClientUri(), gameId);
            restTemplate.postForObject(format, players, ResponseEntity.class);
            System.out.println("I HAVE INFORMED THE RANDOM DATA FOR " + format);
        }
    }

    /**
     * Gets the board of a game
     *
     * @param id - the ID of the game
     * @return - A Board object with BoardElements
     */
    public Board getBoard(String id) {
        GameState gameState = getGameById(id);
        return gameState.getBoard();
    }

    /**
     * Generates a random list of cards for the draw pile
     *
     * @return - List of enum: Card
     */
    public List<Card> generateDrawPile() {
        Random rand = new Random();
        List<Card> drawPile = new ArrayList<>();
        for (int i = 1; i <= 9; i++) {
            int randomNum = rand.nextInt(9) + 1;

            switch (randomNum) {
                case 1:
                    drawPile.add(MOVE1);
                    break;
                case 2:
                    drawPile.add(MOVE2);
                    break;
                case 3:
                    drawPile.add(Card.MOVE3);
                    break;
                case 4:
                    drawPile.add(Card.RIGHT_TURN);
                    break;
                case 5:
                    drawPile.add(Card.LEFT_TURN);
                    break;
                case 6:
                    drawPile.add(Card.AGAIN);
                    break;
                case 7:
                    drawPile.add(Card.UTURN);
                    break;
                case 8:
                    drawPile.add(Card.MOVE_BACK);
                    break;
                case 9:
                    drawPile.add(MOVE1);
                    break;
                default:
                    drawPile.add(Card.MOVE3);
                    break;
            }
        }
        return drawPile;
    }

    /**
     * Updates the player's register deck with the given card
     *
     * @param gameId     - The id of the game
     * @param playerId   - The id of the player
     * @param playerView - The player view
     * @param card       - The card chosen
     * @return -Was the player updated?
     */
    public boolean updateRegisterCard(String gameId, String playerId, PlayerView playerView, Card card) {
        GameState gameState = getGameById(gameId);
        int index = this.gameStates.indexOf(gameState);
        Player player = getPlayerById(gameId, playerId);
        gameState.getPlayers().remove(player);
        Player updatedPlayer = new Player(playerView.getId(), playerView.getName(), playerView.getSecret(), playerView.getClientUri(), playerView.getRobotName());
        updatedPlayer.setPositionX(player.getPositionX());
        updatedPlayer.setPositionY(player.getPositionY());
        if (player.getDirection() != null)
            updatedPlayer.setDirection(player.getDirection());
        else
            updatedPlayer.setDirection(NORTH);

        if (player.getRegisters() == null) {
            List<Card> cards = new ArrayList<>();
            cards.add(card);
            updatedPlayer.setRegisters(cards);

        } else {
            List<Card> cards = player.getRegisters();
            cards.add(card);
            updatedPlayer.setRegisters(cards);
        }

        boolean update = gameState.addPlayer(updatedPlayer);
        this.gameStates.set(index, gameState);
        return update;
    }


    /**
     * If the players fail to choose all 5 cards for their registers, this function chooses random cards for them
     *
     * @param gameId - The id of the game
     * @return - Were the players updated?
     */
    public boolean updateCardsRandom(String gameId) {
        GameState gameState = getGameById(gameId);
        int index = this.gameStates.indexOf(gameState);
        boolean update = false;
        List<Player> players = getAllPlayers(gameId);
        for (Player p : players) {
            Player player = getPlayerById(gameId, p.getId());

            if (player.getRegisters() != null) {
                if (player.getRegisters().size() < 5) {
                    int cardsToPopulate = 5 - player.getRegisters().size();
                    for (int i = 1; i <= cardsToPopulate; i++) {
                        List<Card> drawPile = generateDrawPile();
                        Random rand = new Random();
                        int randomNum = rand.nextInt(8) + 1;
                        Card randomCard = drawPile.get(randomNum);
                        PlayerView playerView = new PlayerView(p.getId(), p.getName(), p.getClientUri(), p.getRobotName(), p.getSecret());
                        updateRegisterCard(gameId, player.getId(), playerView, randomCard);
                    }
                }
            } else {
                for (int i = 1; i <= 5; i++) {
                    List<Card> drawPile = generateDrawPile();
                    Random rand = new Random();
                    int randomNum = rand.nextInt(8) + 1;
                    Card randomCard = drawPile.get(randomNum);
                    PlayerView playerView = new PlayerView(p.getId(), p.getName(), p.getClientUri(), p.getRobotName(), p.getSecret());
                    updateRegisterCard(gameId, player.getId(), playerView, randomCard);
                }
            }
        }
        return update;
    }

    /**
     * Sends request to all connected clients to close the draw pile screen
     *
     * @param gameId  - The id of the game
     * @param players - The list of players belonging to the game
     */
    public void closeDrawPile(String gameId, List<PlayerView> players) {
        for (PlayerView playerView : players) {
            RestTemplate restTemplate = new RestTemplate();
            String format = String.format("%s" + "games/%s/close", playerView.getClientUri(), gameId);
            restTemplate.postForObject(format, players, ResponseEntity.class);
            System.out.println("I HAVE CLOSED THE DRAW PILE SCREEN FOR " + format);
        }
    }

    /**
     * Calculates the new positions of the players on the board
     *
     * @param gameId  - The id of the game
     * @param players - The players to be calculated
     */
    public Player[] calculateRound(String gameId, Player[] players) {
        GameState gameState = getGameById(gameId);
        int index = this.gameStates.indexOf(gameState);

        //Find Players Turn
        Map<String, Integer> playersAndBlocks = new HashMap<>();
        for (Player player : players) {
            int rowAntenna = 12;
            int colAntenna = 4;
            int row = player.getPositionX();
            int column = player.getPositionY();

            int blocksAway = Math.abs(rowAntenna - row) + Math.abs(colAntenna - column);
            playersAndBlocks.put(player.getId(), blocksAway);
        }

        //Sort the players through bubble sort
        int n = players.length;
        Player temp;
        for (int i = 0; i < n; i++) {
            for (int j = 1; j < (n - i); j++) {

                if ((playersAndBlocks.get(players[j - 1].getId()) >= playersAndBlocks.get(players[j].getId()))
                        && (players[j - 1].getPositionY() > players[j].getPositionY())
                        ) {
                    temp = players[j - 1];
                    players[j - 1] = players[j];
                    players[j] = temp;
                }
            }
        }

        // Check where they end up in the board
        for (Player player : players) {
            List<Card> cards = player.getRegisters();
            ListIterator<Card> cardListIterator = cards.listIterator();
            while (cardListIterator.hasNext()) {
                BoardElement currentBoardElement = gameState.getBoard().getElements()[player.getPositionX()][player.getPositionY()];
                BoardElement infrontElement = gameState.getBoard().getElements()[player.getPositionX()][player.getPositionY()];
                BoardElement behindElement = gameState.getBoard().getElements()[player.getPositionX()][player.getPositionY()];
                switch (cardListIterator.next()) {
                    case LEFT_TURN:
                        switch (player.getDirection()) {
                            case NORTH:
                                player.setDirection(WEST);
                                checkBoardElement(player, gameState, LEFT_TURN, NORTH);
                                if (isBeyondTheBoard(player))
                                    KillPlayer(player);
                                break;
                            case SOUTH:
                                player.setDirection(EAST);
                                checkBoardElement(player, gameState, LEFT_TURN, SOUTH);
                                if (isBeyondTheBoard(player))
                                    KillPlayer(player);
                                break;
                            case EAST:
                                player.setDirection(NORTH);
                                checkBoardElement(player, gameState, LEFT_TURN, EAST);
                                if (isBeyondTheBoard(player))
                                    KillPlayer(player);
                                break;
                            case WEST:
                                player.setDirection(SOUTH);
                                checkBoardElement(player, gameState, LEFT_TURN, WEST);
                                if (isBeyondTheBoard(player))
                                    KillPlayer(player);
                                break;
                        }
                        break;
                    case RIGHT_TURN:
                        switch (player.getDirection()) {
                            case NORTH:
                                player.setDirection(EAST);
                                checkBoardElement(player, gameState, RIGHT_TURN, NORTH);
                                if (isBeyondTheBoard(player))
                                    KillPlayer(player);
                                break;
                            case SOUTH:
                                player.setDirection(WEST);
                                checkBoardElement(player, gameState, RIGHT_TURN, SOUTH);
                                if (isBeyondTheBoard(player))
                                    KillPlayer(player);
                                break;
                            case EAST:
                                player.setDirection(SOUTH);
                                checkBoardElement(player, gameState, RIGHT_TURN, EAST);
                                if (isBeyondTheBoard(player))
                                    KillPlayer(player);
                                break;
                            case WEST:
                                player.setDirection(NORTH);
                                checkBoardElement(player, gameState, RIGHT_TURN, WEST);
                                if (isBeyondTheBoard(player))
                                    KillPlayer(player);
                                break;
                        }
                        break;
                    case UTURN:
                        switch (player.getDirection()) {
                            case NORTH:
                                player.setDirection(SOUTH);
                                checkBoardElement(player, gameState, UTURN, NORTH);
                                if (isBeyondTheBoard(player))
                                    KillPlayer(player);
                                break;
                            case SOUTH:
                                player.setDirection(NORTH);
                                checkBoardElement(player, gameState, UTURN, SOUTH);
                                if (isBeyondTheBoard(player))
                                    KillPlayer(player);
                                break;
                            case EAST:
                                player.setDirection(WEST);
                                checkBoardElement(player, gameState, UTURN, EAST);
                                if (isBeyondTheBoard(player))
                                    KillPlayer(player);
                                break;
                            case WEST:
                                player.setDirection(EAST);
                                checkBoardElement(player, gameState, UTURN, WEST);
                                if (isBeyondTheBoard(player))
                                    KillPlayer(player);
                                break;
                        }
                        break;
                    case MOVE1:
                        switch (player.getDirection()) {
                            case NORTH:
                                infrontElement = getInfrontNorth(gameState,player);
                                behindElement = getBehindNorth(gameState, player);
                                if (!isWallBlocking(player, currentBoardElement, infrontElement, behindElement, NORTH, MOVE1))
                                    player.setPositionX(player.getPositionX() - 1);
                                checkBoardElement(player, gameState, MOVE1, NORTH);
                                if (isBeyondTheBoard(player))
                                    KillPlayer(player);
                                break;
                            case SOUTH:
                                behindElement = getBehindSouth(gameState, player);
                                infrontElement = getInfrontSouth(gameState, player);
                                if (!isWallBlocking(player, currentBoardElement, infrontElement, behindElement, SOUTH, MOVE1))
                                    player.setPositionX(player.getPositionX() + 1);
                                checkBoardElement(player, gameState, MOVE1, SOUTH);
                                if (isBeyondTheBoard(player))
                                    KillPlayer(player);
                                break;
                            case EAST:
                                behindElement = getBehindEast(gameState, player);
                                infrontElement = getInfrontEast(gameState, player);
                                if (!isWallBlocking(player, currentBoardElement, infrontElement, behindElement, EAST, MOVE1))
                                    player.setPositionY(player.getPositionY() + 1);
                                checkBoardElement(player, gameState, MOVE1, EAST);
                                if (isBeyondTheBoard(player))
                                    KillPlayer(player);
                                break;
                            case WEST:
                                infrontElement = getInfrontWest(gameState, player);
                                behindElement = getBehindWest(gameState, player);
                                if (!isWallBlocking(player, currentBoardElement, infrontElement, behindElement, WEST, MOVE1))
                                    player.setPositionY(player.getPositionY() - 1);
                                checkBoardElement(player, gameState, MOVE1, WEST);
                                if (isBeyondTheBoard(player))
                                    KillPlayer(player);
                                break;
                        }
                        break;
                    case MOVE2:
                        switch (player.getDirection()) {
                            case NORTH:
                                infrontElement = getInfrontNorth(gameState,player);
                                behindElement = getBehindNorth(gameState, player);
                                if (!isWallBlocking(player, currentBoardElement, infrontElement, behindElement, NORTH, MOVE2)) {
                                    player.setPositionX(player.getPositionX() - 1);
                                    if (isBeyondTheBoard(player)) {
                                        KillPlayer(player);
                                        break;
                                    }
                                    currentBoardElement = gameState.getBoard().getElements()[player.getPositionX()][player.getPositionY()];
                                    infrontElement = getInfrontNorth(gameState,player);
                                    behindElement = getBehindNorth(gameState, player);
                                }
                                if (!isWallBlocking(player, currentBoardElement, infrontElement, behindElement, NORTH, MOVE2)) {
                                    player.setPositionX(player.getPositionX() - 1);
                                }
                                checkBoardElement(player, gameState, MOVE2, NORTH);
                                if (isBeyondTheBoard(player))
                                    KillPlayer(player);
                                break;
                            case SOUTH:
                                behindElement = getBehindSouth(gameState, player);
                                infrontElement = getInfrontSouth(gameState, player);
                                if (!isWallBlocking(player, currentBoardElement, infrontElement, behindElement, SOUTH, MOVE2)) {
                                    player.setPositionX(player.getPositionX() + 1);
                                    if (isBeyondTheBoard(player)) {
                                        KillPlayer(player);
                                        break;
                                    }
                                    behindElement = getBehindSouth(gameState, player);
                                    infrontElement = getInfrontSouth(gameState, player);
                                    currentBoardElement = gameState.getBoard().getElements()[player.getPositionX()][player.getPositionY()];

                                }
                                if (!isWallBlocking(player, currentBoardElement, infrontElement, behindElement, SOUTH, MOVE2))
                                    player.setPositionX(player.getPositionX() + 1);
                                checkBoardElement(player, gameState, MOVE2, SOUTH);
                                if (isBeyondTheBoard(player))
                                    KillPlayer(player);
                                break;
                            case EAST:
                                behindElement = getBehindEast(gameState, player);
                                infrontElement = getInfrontEast(gameState, player);
                                if (!isWallBlocking(player, currentBoardElement, infrontElement, behindElement, EAST, MOVE2)) {
                                    player.setPositionY(player.getPositionY() + 1);
                                    if (isBeyondTheBoard(player)) {
                                        KillPlayer(player);
                                        break;
                                    }
                                    behindElement = getBehindEast(gameState, player);
                                    infrontElement = getInfrontEast(gameState, player);
                                    currentBoardElement = gameState.getBoard().getElements()[player.getPositionX()][player.getPositionY()];

                                }
                                if (!isWallBlocking(player, currentBoardElement, infrontElement, behindElement, EAST, MOVE2))
                                    player.setPositionY(player.getPositionY() + 1);
                                checkBoardElement(player, gameState, MOVE2, EAST);
                                if (isBeyondTheBoard(player))
                                    KillPlayer(player);
                                break;
                            case WEST:
                                infrontElement = getInfrontWest(gameState, player);
                                behindElement = getBehindWest(gameState, player);
                                if (!isWallBlocking(player, currentBoardElement, infrontElement, behindElement, WEST, MOVE2)) {
                                    player.setPositionY(player.getPositionY() - 1);
                                    if (isBeyondTheBoard(player)) {
                                        KillPlayer(player);
                                        break;
                                    }
                                    infrontElement = getInfrontWest(gameState, player);
                                    behindElement = getBehindWest(gameState, player);
                                    currentBoardElement = gameState.getBoard().getElements()[player.getPositionX()][player.getPositionY()];

                                }
                                if (!isWallBlocking(player, currentBoardElement, infrontElement, behindElement, WEST, MOVE2))
                                    player.setPositionY(player.getPositionY() - 1);
                                checkBoardElement(player, gameState, MOVE2, WEST);
                                if (isBeyondTheBoard(player))
                                    KillPlayer(player);
                                break;
                        }
                        break;
                    case MOVE3:
                        switch (player.getDirection()) {
                            case NORTH:
                                infrontElement = getInfrontNorth(gameState,player);
                                behindElement = getBehindNorth(gameState, player);
                                if (!isWallBlocking(player, currentBoardElement, infrontElement, behindElement, NORTH, MOVE3)) {
                                    player.setPositionX(player.getPositionX() - 1);
                                    if (isBeyondTheBoard(player)) {
                                        KillPlayer(player);
                                        break;
                                    }
                                    infrontElement = getInfrontNorth(gameState,player);
                                    behindElement = getBehindNorth(gameState, player);
                                    currentBoardElement = gameState.getBoard().getElements()[player.getPositionX()][player.getPositionY()];

                                }
                                if (!isWallBlocking(player, currentBoardElement, infrontElement, behindElement, NORTH, MOVE3)) {
                                    player.setPositionX(player.getPositionX() - 1);
                                    if (isBeyondTheBoard(player)) {
                                        KillPlayer(player);
                                        break;
                                    }
                                    infrontElement = getInfrontNorth(gameState,player);
                                    behindElement = getBehindNorth(gameState, player);
                                    currentBoardElement = gameState.getBoard().getElements()[player.getPositionX()][player.getPositionY()];

                                }
                                if (!isWallBlocking(player, currentBoardElement, infrontElement, behindElement, NORTH, MOVE3))
                                    player.setPositionX(player.getPositionX() - 1);
                                checkBoardElement(player, gameState, MOVE3, NORTH);
                                if (isBeyondTheBoard(player))
                                    KillPlayer(player);
                                break;
                            case SOUTH:
                                behindElement = getBehindSouth(gameState, player);
                                infrontElement = getInfrontSouth(gameState, player);
                                if (!isWallBlocking(player, currentBoardElement, infrontElement, behindElement, SOUTH, MOVE3)) {
                                    player.setPositionX(player.getPositionX() + 1);
                                    if (isBeyondTheBoard(player)) {
                                        KillPlayer(player);
                                        break;
                                    }
                                    behindElement = getBehindSouth(gameState, player);
                                    infrontElement = getInfrontSouth(gameState, player);
                                    currentBoardElement = gameState.getBoard().getElements()[player.getPositionX()][player.getPositionY()];

                                }
                                if (!isWallBlocking(player, currentBoardElement, infrontElement, behindElement, SOUTH, MOVE3)) {
                                    player.setPositionX(player.getPositionX() + 1);
                                    if (isBeyondTheBoard(player)) {
                                        KillPlayer(player);
                                        break;
                                    }
                                    behindElement = getBehindSouth(gameState, player);
                                    infrontElement = getInfrontSouth(gameState, player);
                                    currentBoardElement = gameState.getBoard().getElements()[player.getPositionX()][player.getPositionY()];

                                }
                                if (!isWallBlocking(player, currentBoardElement, infrontElement, behindElement, SOUTH, MOVE3))
                                    player.setPositionX(player.getPositionX() + 1);
                                checkBoardElement(player, gameState, MOVE3, SOUTH);
                                if (isBeyondTheBoard(player))
                                    KillPlayer(player);
                                break;
                            case EAST:
                                behindElement = getBehindEast(gameState, player);
                                infrontElement = getInfrontEast(gameState, player);
                                if (!isWallBlocking(player, currentBoardElement, infrontElement, behindElement, EAST, MOVE3)) {
                                    player.setPositionY(player.getPositionY() + 1);
                                    if (isBeyondTheBoard(player)) {
                                        KillPlayer(player);
                                        break;
                                    }
                                    behindElement = getBehindEast(gameState, player);
                                    infrontElement = getInfrontEast(gameState, player);
                                    currentBoardElement = gameState.getBoard().getElements()[player.getPositionX()][player.getPositionY()];

                                }
                                if (!isWallBlocking(player, currentBoardElement, infrontElement, behindElement, EAST, MOVE3)) {
                                    player.setPositionY(player.getPositionY() + 1);
                                    if (isBeyondTheBoard(player)) {
                                        KillPlayer(player);
                                        break;
                                    }
                                    behindElement = getBehindEast(gameState, player);
                                    infrontElement = getInfrontEast(gameState, player);
                                    currentBoardElement = gameState.getBoard().getElements()[player.getPositionX()][player.getPositionY()];

                                }
                                if (!isWallBlocking(player, currentBoardElement, infrontElement, behindElement, EAST, MOVE3))
                                    player.setPositionY(player.getPositionY() + 1);
                                checkBoardElement(player, gameState, MOVE3, EAST);
                                if (isBeyondTheBoard(player))
                                    KillPlayer(player);
                                break;
                            case WEST:
                                infrontElement = getInfrontWest(gameState, player);
                                behindElement = getBehindWest(gameState, player);
                                if (!isWallBlocking(player, currentBoardElement, infrontElement, behindElement, WEST, MOVE3)) {
                                    player.setPositionY(player.getPositionY() - 1);
                                    if (isBeyondTheBoard(player)) {
                                        KillPlayer(player);
                                        break;
                                    }
                                    infrontElement = getInfrontWest(gameState, player);
                                    behindElement = getBehindWest(gameState, player);
                                    currentBoardElement = gameState.getBoard().getElements()[player.getPositionX()][player.getPositionY()];

                                }
                                if (!isWallBlocking(player, currentBoardElement, infrontElement, behindElement, WEST, MOVE3)) {
                                    player.setPositionY(player.getPositionY() - 1);
                                    if (isBeyondTheBoard(player)) {
                                        KillPlayer(player);
                                        break;
                                    }
                                    infrontElement = getInfrontWest(gameState, player);
                                    behindElement = getBehindWest(gameState, player);
                                    currentBoardElement = gameState.getBoard().getElements()[player.getPositionX()][player.getPositionY()];

                                }
                                if (!isWallBlocking(player, currentBoardElement, infrontElement, behindElement, WEST, MOVE3))
                                    player.setPositionY(player.getPositionY() - 1);
                                checkBoardElement(player, gameState, MOVE3, WEST);
                                if (isBeyondTheBoard(player))
                                    KillPlayer(player);
                                break;
                        }
                        break;
                    case MOVE_BACK:
                        switch (player.getDirection()) {
                            case NORTH:
                                infrontElement = getInfrontNorth(gameState,player);
                                behindElement = getBehindNorth(gameState, player);
                                if (!isWallBlocking(player, currentBoardElement, infrontElement, behindElement, NORTH, MOVE_BACK))
                                    player.setPositionX(player.getPositionX() + 1);
                                checkBoardElement(player, gameState, MOVE_BACK, NORTH);
                                if (isBeyondTheBoard(player))
                                    KillPlayer(player);
                                break;
                            case SOUTH:
                                behindElement = getBehindSouth(gameState, player);
                                infrontElement = getInfrontSouth(gameState, player);
                                if (!isWallBlocking(player, currentBoardElement, infrontElement, behindElement, SOUTH, MOVE_BACK))
                                    player.setPositionX(player.getPositionX() - 1);
                                checkBoardElement(player, gameState, MOVE_BACK, SOUTH);
                                if (isBeyondTheBoard(player))
                                    KillPlayer(player);
                                break;
                            case EAST:
                                behindElement = getBehindEast(gameState, player);
                                infrontElement = getInfrontEast(gameState, player);
                                if (!isWallBlocking(player, currentBoardElement, infrontElement, behindElement, EAST, MOVE_BACK))
                                    player.setPositionY(player.getPositionY() - 1);
                                checkBoardElement(player, gameState, MOVE_BACK, EAST);
                                if (isBeyondTheBoard(player))
                                    KillPlayer(player);
                                break;
                            case WEST:
                                infrontElement = getInfrontWest(gameState, player);
                                behindElement = getBehindWest(gameState, player);
                                if (!isWallBlocking(player, currentBoardElement, infrontElement, behindElement, WEST, MOVE_BACK))
                                    player.setPositionY(player.getPositionY() + 1);
                                checkBoardElement(player, gameState, MOVE_BACK, WEST);
                                if (isBeyondTheBoard(player))
                                    KillPlayer(player);
                                break;
                        }
                        break;
                    default:
                        break;

                }
            }
            //player.getRegisters().clear();
        }

        //Clear the GameState and add the sorted player list to it
        gameState.getPlayers().clear();

        for (Player p : players) {
            gameState.addPlayer(p);
            System.out.println(p.getName());
        }

        this.gameStates.set(index, gameState);
        return players;
    }

    private boolean isWallBlocking(Player player, BoardElement boardElement, BoardElement infront, BoardElement behind, Direction direction, Card card) {
        boolean isWallBlocking = false;
        switch (boardElement) {
            case WALL_NORTH_SL_START:
            case WALL_NORTH_DL_START:
            case WALL_NORTH_SL_END:
            case WALL_NORTH_DL_END:
            case WALL_NORTH:
                switch (direction) {
                    case NORTH:
                        isWallBlocking = true;
                        break;
                    case SOUTH:
                        switch (card) {
                            case MOVE_BACK:
                                isWallBlocking = true;
                                break;
                        }
                        break;
                }
                break;
            case WALL_SOUTH_SL_START:
            case WALL_SOUTH_DL_START:
            case WALL_SOUTH_SL_END:
            case WALL_SOUTH_DL_END:
            case WALL_SOUTH:
                switch (direction) {
                    case SOUTH:
                        isWallBlocking = true;
                        break;
                    case NORTH:
                        switch (card) {
                            case MOVE_BACK:
                                isWallBlocking = true;
                                break;
                        }
                        break;
                }
                break;
            case WALL_EAST_SL_START:
            case WALL_EAST_DL_START:
            case WALL_EAST_SL_END:
            case WALL_EAST_DL_END:
            case WALL_EAST:
                switch (direction) {
                    case EAST:
                        isWallBlocking = true;
                        break;
                    case WEST:
                        switch (card) {
                            case MOVE_BACK:
                                isWallBlocking = true;
                                break;
                        }
                        break;
                }
                break;
            case WALL_WEST_SL_START:
            case WALL_WEST_DL_START:
            case WALL_WEST_SL_END:
            case WALL_WEST_DL_END:
            case WALL_WEST:
                switch (direction) {
                    case WEST:
                        isWallBlocking = true;
                        break;
                    case EAST:
                        switch (card) {
                            case MOVE_BACK:
                                isWallBlocking = true;
                                break;
                        }
                        break;
                }
                break;
        }

        switch (infront){
            case WALL_SOUTH_SL_START:
            case WALL_SOUTH_DL_START:
            case WALL_SOUTH_SL_END:
            case WALL_SOUTH_DL_END:
            case WALL_SOUTH:
                switch (direction) {
                    case NORTH:
                        isWallBlocking = true;
                        break;
                }
                break;
            case WALL_NORTH_SL_START:
            case WALL_NORTH_DL_START:
            case WALL_NORTH_SL_END:
            case WALL_NORTH_DL_END:
            case WALL_NORTH:
                switch (direction) {
                    case SOUTH:
                        isWallBlocking = true;
                        break;
                }
                break;
            case WALL_WEST_SL_START:
            case WALL_WEST_DL_START:
            case WALL_WEST_SL_END:
            case WALL_WEST_DL_END:
            case WALL_WEST:
                switch (direction) {
                    case EAST:
                        isWallBlocking = true;
                        break;
                }
                break;
            case WALL_EAST_SL_START:
            case WALL_EAST_DL_START:
            case WALL_EAST_SL_END:
            case WALL_EAST_DL_END:
            case WALL_EAST:
                switch (direction) {
                    case WEST:
                        isWallBlocking = true;
                        break;
                }
                break;
        }

        switch (infront){
            case WALL_SOUTH_SL_START:
            case WALL_SOUTH_DL_START:
            case WALL_SOUTH_SL_END:
            case WALL_SOUTH_DL_END:
            case WALL_SOUTH:
                switch (direction) {
                    case NORTH:
                        isWallBlocking = true;
                        break;
                }
                break;
            case WALL_NORTH_SL_START:
            case WALL_NORTH_DL_START:
            case WALL_NORTH_SL_END:
            case WALL_NORTH_DL_END:
            case WALL_NORTH:
                switch (direction) {
                    case SOUTH:
                        isWallBlocking = true;
                        break;
                }
                break;
            case WALL_WEST_SL_START:
            case WALL_WEST_DL_START:
            case WALL_WEST_SL_END:
            case WALL_WEST_DL_END:
            case WALL_WEST:
                switch (direction) {
                    case EAST:
                        isWallBlocking = true;
                        break;
                }
                break;
            case WALL_EAST_SL_START:
            case WALL_EAST_DL_START:
            case WALL_EAST_SL_END:
            case WALL_EAST_DL_END:
            case WALL_EAST:
                switch (direction) {
                    case WEST:
                        isWallBlocking = true;
                        break;
                }
                break;
        }

        switch (behind) {
            case WALL_NORTH_SL_START:
            case WALL_NORTH_DL_START:
            case WALL_NORTH_SL_END:
            case WALL_NORTH_DL_END:
            case WALL_NORTH:
                switch (direction) {
                    case NORTH:
                        switch (card) {
                            case MOVE_BACK:
                                isWallBlocking = true;
                                break;
                        }
                        break;
                }
                break;
            case WALL_SOUTH_SL_START:
            case WALL_SOUTH_DL_START:
            case WALL_SOUTH_SL_END:
            case WALL_SOUTH_DL_END:
            case WALL_SOUTH:
                switch (direction) {
                    case SOUTH:
                        switch (card) {
                            case MOVE_BACK:
                                isWallBlocking = true;
                                break;
                        }
                        break;
                }
                break;
            case WALL_EAST_SL_START:
            case WALL_EAST_DL_START:
            case WALL_EAST_SL_END:
            case WALL_EAST_DL_END:
            case WALL_EAST:
                switch (direction) {
                    case EAST:
                        switch (card) {
                            case MOVE_BACK:
                                isWallBlocking = true;
                                break;
                        }
                        break;
                }
                break;
            case WALL_WEST_SL_START:
            case WALL_WEST_DL_START:
            case WALL_WEST_SL_END:
            case WALL_WEST_DL_END:
            case WALL_WEST:
                switch (direction) {
                    case WEST:
                        switch (card) {
                            case MOVE_BACK:
                                isWallBlocking = true;
                                break;
                        }
                        break;
                }
                break;
        }

        return isWallBlocking;
    }

    private boolean isBeyondTheBoard(Player player) {
        if (player.getPositionY() < 0)
            return true;
        else if (player.getPositionY() > 9)
            return true;
        else if (player.getPositionX() < 0)
            return true;
        else if (player.getPositionX() > 12)
            return true;
        else
            return false;
    }

    private void KillPlayer(Player player) {
        player.setPositionX(5);
        player.setPositionY(3);
        player.setDirection(NORTH);
    }

    private void checkBoardElement(Player player, GameState gameState, Card card, Direction direction) {
        BoardElement boardElement = EMPTY;
        if (!isBeyondTheBoard(player)) {
            boardElement = gameState.getBoard().getElements()[player.getPositionX()][player.getPositionY()];
        }

        switch (boardElement) {
            case SLOW_CB_NORTH_SL:
            case SLOW_CB_NORTH:
                player.setPositionX(player.getPositionX() - 1);
                break;
            case SLOW_CB_SOUTH_SL:
            case SLOW_CB_SOUTH:
                player.setPositionX(player.getPositionX() + 1);
                break;
            case SLOW_CB_EAST_SL:
            case SLOW_CB_EAST:
                player.setPositionY(player.getPositionY() + 1);
                break;
            case SLOW_CB_WEST_SL:
            case SLOW_CB_WEST:
                player.setPositionY(player.getPositionY() - 1);
                break;
            case FAST_CB_NORTH_SL:
            case FAST_CB_NORTH:
                player.setPositionX(player.getPositionX() - 2);
                break;
            case FAST_CB_SOUTH_SL:
            case FAST_CB_SOUTH:
                player.setPositionX(player.getPositionX() + 2);
                break;
            case FAST_CB_EAST_SL:
            case FAST_CB_EAST:
                player.setPositionY(player.getPositionY() + 2);
                break;
            case FAST_CB_WEST_SL:
            case FAST_CB_WEST:
                player.setPositionY(player.getPositionY() - 2);
                break;
            case FAST_CB_CROSS_CW_9_TO_12:
            case FAST_CB_CROSS_CCW_9_TO_12:
                switch (direction) {
                    case NORTH:
                        player.setDirection(EAST);
                        player.setPositionY(player.getPositionY() + 1);
                        break;
                    case SOUTH:
                        player.setDirection(WEST);
                        player.setPositionY(player.getPositionY() + 1);
                        break;
                    case EAST:
                        player.setDirection(SOUTH);
                        player.setPositionY(player.getPositionY() + 1);
                        break;
                    case WEST:
                        player.setDirection(NORTH);
                        player.setPositionY(player.getPositionY() + 1);
                        break;
                }
                break;
            case FAST_CB_CROSS_CW_12_TO_3:
            case FAST_CB_CROSS_CCW_12_TO_3:
                switch (direction) {
                    case NORTH:
                        player.setDirection(EAST);
                        player.setPositionX(player.getPositionX() + 1);
                        break;
                    case SOUTH:
                        player.setDirection(WEST);
                        player.setPositionX(player.getPositionX() + 1);
                        break;
                    case EAST:
                        player.setDirection(SOUTH);
                        player.setPositionX(player.getPositionX() + 1);
                        break;
                    case WEST:
                        player.setDirection(NORTH);
                        player.setPositionX(player.getPositionX() + 1);
                        break;
                }
                break;
            case FAST_CB_CROSS_CW_6_TO_9:
            case FAST_CB_CROSS_CCW_6_TO_9:
                switch (direction) {
                    case NORTH:
                        player.setDirection(EAST);
                        player.setPositionX(player.getPositionX() - 1);
                        break;
                    case SOUTH:
                        player.setDirection(WEST);
                        player.setPositionX(player.getPositionX() - 1);
                        break;
                    case EAST:
                        player.setDirection(SOUTH);
                        player.setPositionX(player.getPositionX() - 1);
                        break;
                    case WEST:
                        player.setDirection(NORTH);
                        player.setPositionX(player.getPositionX() - 1);
                        break;
                }
                break;
            case FAST_CB_CROSS_CW_3_TO_6:
            case FAST_CB_CROSS_CCW_3_TO_6:
                switch (direction) {
                    case NORTH:
                        player.setDirection(WEST);
                        player.setPositionY(player.getPositionY() - 1);
                        break;
                    case SOUTH:
                        player.setDirection(EAST);
                        player.setPositionY(player.getPositionY() - 1);
                        break;
                    case EAST:
                        player.setDirection(NORTH);
                        player.setPositionY(player.getPositionY() - 1);
                        break;
                    case WEST:
                        player.setDirection(SOUTH);
                        player.setPositionY(player.getPositionY() - 1);
                        break;
                }
                break;
        }
    }

    BoardElement getInfrontNorth(GameState gameState, Player player){
        if (!(player.getPositionX() - 1 < 0))
            return gameState.getBoard().getElements()[player.getPositionX() - 1][player.getPositionY()];
        else
            return EMPTY;
    }

    BoardElement getBehindNorth(GameState gameState, Player player){
        if (!(player.getPositionX() + 1 > 12))
            return gameState.getBoard().getElements()[player.getPositionX() + 1][player.getPositionY()];
        else
            return EMPTY;
    }

    BoardElement getInfrontSouth(GameState gameState, Player player){
        if (!(player.getPositionX() + 1 > 12))
            return gameState.getBoard().getElements()[player.getPositionX() + 1][player.getPositionY()];
        else
            return EMPTY;
    }

    BoardElement getBehindSouth(GameState gameState, Player player){
        if (!(player.getPositionX() - 1 < 0))
            return gameState.getBoard().getElements()[player.getPositionX() - 1][player.getPositionY()];
        else
            return EMPTY;
    }

    BoardElement getInfrontEast(GameState gameState, Player player){
        if (!(player.getPositionY() + 1 > 9))
            return gameState.getBoard().getElements()[player.getPositionX()][player.getPositionY() + 1];
        else
            return EMPTY;
    }

    BoardElement getBehindEast(GameState gameState, Player player){
        if (!(player.getPositionY() - 1 < 0))
            return gameState.getBoard().getElements()[player.getPositionX()][player.getPositionY() - 1];
        else
            return EMPTY;
    }

    BoardElement getInfrontWest(GameState gameState, Player player){
        if (!(player.getPositionY() - 1 < 0))
            return gameState.getBoard().getElements()[player.getPositionX()][player.getPositionY() - 1];
        else
            return EMPTY;
    }

    BoardElement getBehindWest(GameState gameState, Player player){
        if (!(player.getPositionY() + 1 > 9))
            return gameState.getBoard().getElements()[player.getPositionX()][player.getPositionY() + 1];
        else
            return EMPTY;
    }

    /**
     * Sends request to all connected clients to update the Board
     *
     * @param gameId  - The id of the game
     * @param newPlayers - The list of players belonging to the game
     */
    public void roundCalculated(String gameId, Player[] newPlayers) {
        for (Player player : newPlayers) {
            RestTemplate restTemplate = new RestTemplate();
            String format = String.format("%s" + "games/%s/roundCalculated", player.getClientUri(), gameId);
            restTemplate.postForObject(format, newPlayers, ResponseEntity.class);
            System.out.println("I HAVE CALCULATED ROUND FOR " + format);
        }
    }

    public void startDrawPile(String gameId, List<PlayerView> playerViews) {
        for (PlayerView player : playerViews) {
            RestTemplate restTemplate = new RestTemplate();
            String format = String.format("%s" + "games/%s/startDrawPile", player.getClientUri(), gameId);
            restTemplate.postForObject(format, playerViews, ResponseEntity.class);
            System.out.println("I HAVE STARTED DRAW PILE SCREEN FOR " + format);
        }
    }
}
