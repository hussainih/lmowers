package de.fh.kiel.roborally.controller.outgoing;

/**
 * View for a time limit warning
 *
 * @author jpr
 */
public class TimeLimitWarningView {
    private int secondsLeft;
    private String reason;


    /**
     * Empty constructor for Needed when incoming requests body data needs to be deserialized into an instance of {@link TimeLimitWarningView}
     */
    public TimeLimitWarningView() {
    }

    /**
     * Constructor
     *
     * @param secondsLeft the seconds left until timeout
     * @param reason      the reason why the time limit warning occurred
     */
    public TimeLimitWarningView(final int secondsLeft, final String reason) {
        this.secondsLeft = secondsLeft;
        this.reason = reason;
    }

    public int getSecondsLeft() {
        return secondsLeft;
    }


    public String getReason() {
        return reason;
    }

    public void setSecondsLeft(final int secondsLeft) {
        this.secondsLeft = secondsLeft;
    }

    public void setReason(final String reason) {
        this.reason = reason;
    }
}
