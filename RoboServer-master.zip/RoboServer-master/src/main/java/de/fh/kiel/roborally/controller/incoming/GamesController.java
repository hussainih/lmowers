package de.fh.kiel.roborally.controller.incoming;

import java.util.*;

import de.fh.kiel.roborally.model.Board;
import de.fh.kiel.roborally.model.Card;
import de.fh.kiel.roborally.model.GameState;
import de.fh.kiel.roborally.model.Player;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

/**
 * Endpoints for incoming requests from clients, that are related to basic operations on a game like
 * <ol>
 * <li>creating a game</li>
 * <li>joining a game</li>
 * <li>list all games</li>
 * </ol>
 *
 * @author jpr
 */
@RestController
public class GamesController {

    private final RestTemplate restTemplate = new RestTemplate();

    @Autowired
    private final GamesService gamesService;

    public GamesController(GamesService gamesService) {
        this.gamesService = gamesService;
    }

    /**
     * Lists all games, that have been not started yet
     *
     * @return the list of games, that haven't been started yet
     */
    @GetMapping("/games/list")
    public ResponseEntity<List<GameView>> getAllGames() {
        List<GameView> gameViews = new ArrayList<>();
        for(GameState gameState : this.gamesService.getAllGames()) {
            GameView temp = new GameView(gameState.getId(), gameState.getGameName(), gameState.getMaxRobotCount(), gameState.getPlayers().size());
            gameViews.add(temp);
        }
        return ResponseEntity.ok(gameViews);
    }

    /**
     * Creates a new game with a random ID and 1 Robot (the player who created it)
     *
     * @param gameView The body of values needed to create a game
     * @return the game that was created
     */
    @PostMapping("/games/create")
    public ResponseEntity<GameView> createGame(@RequestBody GameView gameView){
        System.out.println(gameView.getName());
        gameView.setId(UUID.randomUUID().toString());
        this.gamesService.createGame(gameView);
        return ResponseEntity.ok(gameView);
    }

    /**
     * Joins a given game and updates all clients about the new player
     * @param id - Id of the game to join
     * @param playerView - Data for the player that's joining
     * @return the game that was updated
     */
    @PostMapping("/games/{id}/join")
    ResponseEntity updateGame(@PathVariable(value = "id") String id, @RequestBody PlayerView playerView){
        playerView.setId(UUID.randomUUID().toString());
        playerView.setRobotName("");
        boolean add = this.gamesService.joinGame(id, playerView);

        if (add){
            List<PlayerView> playerViews = new ArrayList<>();
            for(Player player : this.gamesService.getAllPlayers(id)) {
                PlayerView temp = new PlayerView(player.getId(), player.getName(), player.getClientUri(), player.getRobotName());
                playerViews.add(temp);
            }

            if (playerViews.size() > 1)
                this.gamesService.updatePreGame(id, playerViews);

            return ResponseEntity.ok(playerView);
        }
        else {
            return new ResponseEntity<>("Game is full", HttpStatus.BAD_REQUEST);
        }
    }

    /**
     * Returns the list of players in a game
     * @param id The ID of the game
     * @return List of players in a game
     */
    @GetMapping("/games/{id}/list")
    ResponseEntity<List<PlayerView>> getAllPlayers(@PathVariable(value = "id") String id){
        List<PlayerView> playerViews = new ArrayList<>();
        for(Player player : this.gamesService.getAllPlayers(id)) {
            PlayerView temp = new PlayerView(player.getId(), player.getName(), player.getClientUri(), player.getRobotName());
            playerViews.add(temp);
        }
        return ResponseEntity.ok(playerViews);
    }

    @GetMapping("/games/{id}/tempList")
    ResponseEntity<List<Player>> getAllTempPlayers(@PathVariable(value = "id") String id) {
        List<Player> players = this.gamesService.getAllPlayers(id);
        return ResponseEntity.ok(players);
    }

    /**
     * Updates all clients to start the game -> Moves to choosing Robots and Start Positions
     * @param id - The game to be started
     * @return - An OK status if all went well
     */
    @PostMapping("/games/{id}/start")
    ResponseEntity startGame(@PathVariable(value = "id") String id){
        List<PlayerView> playerViews = new ArrayList<>();
        for(Player player : this.gamesService.getAllPlayers(id)) {
            PlayerView temp = new PlayerView(player.getId(), player.getName(), player.getClientUri(), player.getRobotName());
            playerViews.add(temp);
        }

        this.gamesService.startGames(id, playerViews);
        SelectionRoundController selectionRoundController = new SelectionRoundController(id, playerViews, this.gamesService);
        selectionRoundController.start();
        System.out.println("timer started");
        return new ResponseEntity(HttpStatus.OK);
    }


    /**
     * Updates all
     * @param id - The game to update
     * @param playerView - The player that chose a Robot
     * @return - An OK Status if all went well
     */
    @PostMapping("/games/{id}/robot")
    ResponseEntity chooseRobot(@PathVariable(value = "id") String id, @RequestBody PlayerView playerView){
        boolean update = this.gamesService.updatePlayerRobot(id, playerView.getId(), playerView);

        List<PlayerView> playerViews = new ArrayList<>();
        for(Player player : this.gamesService.getAllPlayers(id)) {
            PlayerView temp = new PlayerView(player.getId(), player.getName(), player.getClientUri(), player.getRobotName());
            playerViews.add(temp);
        }
        this.gamesService.chooseRobot(id, playerViews);
        return new ResponseEntity(HttpStatus.OK);
    }

    /**
     * Gets the chosen position from the client to update
     * @param id - ID of the game
     * @param playerId - The ID of the player whose positions are sent
     * @param posX - The X position of the player
     * @param posY - The Y position of the player
     * @return - An OK status if all went well
     */
    @PostMapping(value = "/games/{id}/position")
    ResponseEntity choosePosition(@PathVariable(value = "id") String id, @RequestParam(value = "pid") String playerId, @RequestParam(value = "posX") String posX, @RequestParam(value = "posY") String posY){
        Player player = this.gamesService.getPlayerById(id, playerId);
        PlayerView playerView = new PlayerView(player.getId(), player.getName(), player.getClientUri(), player.getRobotName(), player.getSecret());
        boolean update = this.gamesService.updatePlayerPosition(id, playerView.getId(), playerView, Integer.parseInt(posX), Integer.parseInt(posY));

        List<PlayerView> playerViews = new ArrayList<>();
        for(Player p : this.gamesService.getAllPlayers(id)) {
            PlayerView temp = new PlayerView(p.getId(), p.getName(), p.getClientUri(), p.getRobotName());
            playerViews.add(temp);
        }
        this.gamesService.choosePosition(id, playerViews, posX, posY, player.getName());
        return new ResponseEntity(HttpStatus.OK);
    }

    /**
     * Gets the board layout of the game
     * @param id - The id of the game
     * @return - A Board object
     */
    @GetMapping("/games/{id}/board")
    ResponseEntity<Board> getBoard(@PathVariable(value = "id") String id){
        return ResponseEntity.ok(this.gamesService.getBoard(id));
    }


    /**
     * Gets a randomly generated draw pile
     * @return - A list of random cards from Enum: Card
     */
    @GetMapping("/games/getDrawPile")
    ResponseEntity<List<Card>> getDrawPile(){
        return ResponseEntity.ok(this.gamesService.generateDrawPile());
    }

    /**
     * Updates the player's register with the chosen card from the client
     * @param id - The id of the game
     * @param playerId - The id of the player
     * @param card - The chosen card
     * @return - An OK status if all went well
     */
    @PostMapping("/games/{id}/registerCard")
    ResponseEntity chooseCard(@PathVariable(value = "id") String id, @RequestParam(value = "pid") String playerId, @RequestParam(value = "card") String card){
        Player player = this.gamesService.getPlayerById(id, playerId);
        PlayerView playerView = new PlayerView(player.getId(), player.getName(), player.getClientUri(), player.getRobotName(), player.getSecret());
        boolean update = this.gamesService.updateRegisterCard(id, playerView.getId(), playerView, Card.valueOf(card));
        return new ResponseEntity(HttpStatus.OK);
    }

    @PostMapping("/games/{id}/round")
    @ResponseStatus(value = HttpStatus.OK)
    void calculateRound(@PathVariable(value = "id") String gameId){
        List<Player> playerList = this.gamesService.getAllPlayers(gameId);
        Player[] players = playerList.toArray(new Player[0]);
        Player[] newPlayers = this.gamesService.calculateRound(gameId, players);
        this.gamesService.roundCalculated(gameId, newPlayers);

        List<PlayerView> playerViews = new ArrayList<>();
        for(Player p : this.gamesService.getAllPlayers(gameId)) {
            PlayerView temp = new PlayerView(p.getId(), p.getName(), p.getClientUri(), p.getRobotName());
            playerViews.add(temp);
        }
        DrawPileScreenActivate drawPileScreenActivate = new DrawPileScreenActivate(gameId, playerViews, gamesService);
        drawPileScreenActivate.start();
        //return ResponseEntity.ok(newPlayers);
    }



    /**
     * Used to start a timer in the Selection Round of the client
     * Will change screen of all connected clients of the game
     *
     * If Client has not chosen a Robot or Start Position, server provides a random one.
     */
    public class SelectionRoundController extends Thread {
        String gameId;
        List<PlayerView> playerViews;
        GamesService gamesService;

        public SelectionRoundController(String gameId, List<PlayerView> playerViews, GamesService gamesService) {
            this.gameId = gameId;
            this.playerViews = playerViews;
            this.gamesService = gamesService;
        }

        @Override
        public void run() {
            Timer timer = new Timer();
            timer.schedule(new TimerTask() {
                @Override
                public void run() {
                    boolean updateRandom = gamesService.updatePlayerRandom(gameId, playerViews);
                    gamesService.randomiseSelection(gameId, playerViews);
                    RegisterCardSelection registerCardSelection = new RegisterCardSelection(gameId, playerViews, gamesService);
                    registerCardSelection.start();

                }
            }, 15000, 999999999);
        }
    }

    /**
     * Used to start a timer in the game when selecting registers from the Draw Pile
     * Will close the draw pile screen for all clients
     *
     * If Client has failed to choose 5 cards for registers, server provides random cards.
     */
    public class RegisterCardSelection extends Thread {
        String gameId;
        List<PlayerView> playerViews;
        GamesService gamesService;

        public RegisterCardSelection(String gameId, List<PlayerView> playerViews, GamesService gamesService) {
            this.gameId = gameId;
            this.playerViews = playerViews;
            this.gamesService = gamesService;
        }

        @Override
        public void run() {
            Timer timer = new Timer();
            timer.schedule(new TimerTask() {
                @Override
                public void run() {
                    boolean updateCards = gamesService.updateCardsRandom(gameId);
                    gamesService.closeDrawPile(gameId, playerViews);

                }
            }, 20000, 999999999);
        }
    }

    public class DrawPileScreenActivate extends Thread{
        String gameId;
        List<PlayerView> playerViews;
        GamesService gamesService;

        public DrawPileScreenActivate(String gameId, List<PlayerView> playerViews, GamesService gamesService) {
            this.gameId = gameId;
            this.playerViews = playerViews;
            this.gamesService = gamesService;
        }

        @Override
        public void run() {
            Timer timer = new Timer();
            timer.schedule(new TimerTask() {
                @Override
                public void run() {
                    gamesService.startDrawPile(gameId, playerViews);
                    RegisterCardSelection registerCardSelection = new RegisterCardSelection(gameId, playerViews, gamesService);
                    registerCardSelection.start();
                }
            }, 30000, 999999999);
        }
    }
}
