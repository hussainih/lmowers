package de.fh.kiel.roborally.controller.incoming;

import de.fh.kiel.roborally.model.Player;

import java.util.HashSet;
import java.util.Set;

/**
 * View for a single robo rally game
 *
 * @author jpr
 */
public class GameView {
    private String id;
    private String name;
    private int maxRobotCount;
    private int currentRobotCount;

    /**
     * Empty constructor. Needed when incoming requests body data needs to be deserialized into an instance of {@link GameView}
     */
    public GameView() {
    }

    /**
     * Constructor
     *
     * @param id                the id of the game
     * @param name              the name of the game
     * @param maxRobotCount     the maximum number of robots
     * @param currentRobotCount the count of joined robots
     */
    public GameView(final String id, final String name, final int maxRobotCount, final int currentRobotCount) {
        this.id = id;
        this.name = name;
        this.maxRobotCount = maxRobotCount;
        this.currentRobotCount = currentRobotCount;
    }

    public String getId() {
        return id;
    }

    public void setId(final String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public int getMaxRobotCount() {
        return maxRobotCount;
    }

    public void setMaxRobotCount(final int maxRobotCount) {
        this.maxRobotCount = maxRobotCount;
    }

    public int getCurrentRobotCount() {
        return currentRobotCount;
    }

    public void setCurrentRobotCount(final int currentRobotCount) {
        this.currentRobotCount = currentRobotCount;
    }

}
