package de.fh.kiel.roborally.controller.outgoing;

import java.util.List;

import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import de.fh.kiel.roborally.model.Player;

/**
 * Sends data from server to client regarding informations of a round for a particular game
 *
 * @author jpr
 */
@Component
public class RoundController {

    /**
     * Server sends this timelimit warning if either a client has finished programming the registers
     * for this round or the server decides, that it is time to finish the current
     * round for some other reason.
     *
     * @param gameId  ID of the game
     * @param players the players to inform
     */
    public void sendTimeLimitWarning(final String gameId, final List<Player> players) {
        players.forEach(p -> {
            RestTemplate restTemplate = new RestTemplate();
            String format = String.format("%s/games/%s/round/timeLimitWarning", p.getClientUri(), gameId);
            restTemplate.postForEntity(format, new HttpEntity<>(new TimeLimitWarningView(60, "because")), Void.class);
        });
    }

}
