package de.fh.kiel.roborally.model;

/**
 * Representation of the Board.
 * <br/>It consists of {@link BoardElement BoardElements}.
 * @author jpr
 */
public class Board {
    private BoardElement[][] elements;

    public Board() {
    }

    public BoardElement[][] getElements() {
        return elements;
    }

    public void setElements(BoardElement[][] elements) {
        this.elements = elements;
    }
}
