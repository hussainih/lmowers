/**
 * This package contains all controllers, that process outgoing requests to clients of games
 *
 * @author jpr
 */
package de.fh.kiel.roborally.controller.outgoing;