package de.fh.kiel.roborally;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
public class RoborallyApplication {

    public static void main(String[] args) {
        SpringApplication.run(RoborallyApplication.class, args);
    }
}