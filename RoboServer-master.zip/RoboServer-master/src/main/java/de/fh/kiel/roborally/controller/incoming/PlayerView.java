package de.fh.kiel.roborally.controller.incoming;

import de.fh.kiel.roborally.model.Player;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

public class PlayerView {
    private String id;
    private String name;
    private String clientUri;
    private String robotName;
    private String secret;

        /**
     * Creates a new Player.
     *
     * @param id        the Players ID, they can choose it themselves
     * @param name      the name a Player has given themselves
     * @param secret    the secret provided by the game server in order to verify the identity of this player; for
     *                  security reasons only a hash should be provided
     * @param clientUri the URI where the player can be reached via http; for example http://localhost:8081/
     * @param robotName the name of the Robot, for example Smash Bot
     */
    public PlayerView(String id, String name, String clientUri, String robotName, String secret) {
        this.id = id;
        this.name = name;
        this.clientUri = clientUri;
        this.robotName = robotName;
        this.secret = secret;
    }

    public PlayerView(){

    }

    public PlayerView(String id, String name, String clientUri, String robotName) {
        this.id = id;
        this.name = name;
        this.clientUri = clientUri;
        this.robotName = robotName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getClientUri() {
        return clientUri;
    }

    public void setClientUri(String clientUri) {
        this.clientUri = clientUri;
    }

    public String getRobotName() {
        return robotName;
    }

    public void setRobotName(String robotName) {
        this.robotName = robotName;
    }

    public String getSecret() {
        return secret;
    }

    public void setSecret(String secret) {
        this.secret = secret;
    }


    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }

        if (!(o instanceof PlayerView)) {
            return false;
        }

        PlayerView player = (PlayerView) o;

        return new EqualsBuilder().append(id, player.id).append(name, player.name).append(clientUri, player.clientUri).isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37).append(id).append(name).append(clientUri).toHashCode();
    }
}
